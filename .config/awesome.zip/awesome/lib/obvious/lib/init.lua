------------------------------------------
-- Author: Andrei "Garoth" Thorp        --
-- Copyright 2009 Andrei "Garoth" Thorp --
------------------------------------------

require("obvious.lib.hooks")
require("obvious.lib.markup")
require("obvious.lib.mpd")
require("obvious.lib.widget")
require("obvious.lib.wlan")

module("obvious.lib")

-- vim:ft=lua:ts=2:sw=2:sts=2:tw=80:et
