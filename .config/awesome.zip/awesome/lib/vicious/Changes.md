# Changes in 2.3.1

Fixes:

- widgets can be a function again (regression introduced in 2.3.0)

# Changes in 2.3.0

Features:
- add btc widget
- add cmus widget
- alsa mixer also accept multiple arguments

Fixes:

- pkg now uses non-blocking asynchronous api

# Changes in 2.2.0

Notable changes:

- moved development from git.sysphere.org/vicious to github.com/Mic92/vicious
- official freebsd support
- escape variables before passing to shell
- support for gear timers
- fix weather widget url
- add vicious.call() method to obtain data outside of widgets

For older versions see git log
