--[[

     Licensed under MIT
     * (c) 2017, Egor Churaev egor.churaev@gmail.com

--]]

return {
    kbdcfg = require("keyboard_layout.kbdcfg")
}
